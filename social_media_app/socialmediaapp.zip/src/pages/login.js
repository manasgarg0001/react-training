import {
  Button,
  Checkbox,
  TextField,
  Typography,
  Link,
  CardMedia,
  Grid,
} from "@mui/material";
import { Box } from "@mui/system";
import { Field, Form, Formik } from "formik";
import React from "react";
import * as Yup from "yup";
import RecipeReviewCard from "./card";
import Google from "../assets/image2.png";
import Logimg from "../assets/logimg.jpg";
import { useNavigate } from "react-router-dom";
const Login = () => {
  const SignupSchema = Yup.object().shape({
    email: Yup.string()
      .email("*please enter a valid email address")
      .required("*email is required"),
    password: Yup.string()
      .min(8, "password must be 8 characters long!")
      .max(30, "password must not exceed 30 characters!")
      .required("password is required"),
  });
  const Navigate = useNavigate();
  return (
    // <RecipeReviewCard>
    <>
      <Grid container sx={{ height: "100vh" }}>
        <Grid item xs={6}>
          <CardMedia
            sx={{ height: "100%" }}
            component="img"
            src={Logimg}
            alt="Paella dish"
          />
        </Grid>
        <Grid item xs={6} sx={{ display: "flex", justifyContent: "center" }}>
          <Box
            sx={{
              width: "50%",

              height: "100vh",
              justifyContent: "center",
            }}
          >
            <Box sx={{ padding: "20px" }}>
              <Typography
                variant="h4"
                gutterBottom
                sx={{
                  fontWeight: "700",
                  fontSize: "36px",
                  lineHeight: "49px",
                  color: "#525252",
                }}
              >
                Login To Your Account
                <Typography variant="subtitle1" gutterBottom>
                  See what is going on with your business
                </Typography>
              </Typography>
              <Box
                sx={{
                  display: "flex",
                  alignSelf: "center",
                  justifyContent: "center",
                }}
              >
                <img src={Google} sx={{ justifyContent: "center" }} />
                <Button
                  variant="contained"
                  sx={{
                    fontWeight: "700",
                    fontSize: "14px",
                    lineHeight: "19px",
                    textAlign: "center",
                  }}
                >
                  Continue with google
                </Button>
              </Box>
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <Typography
                  variant="subtitle1"
                  gutterBottom
                  sx={{
                    fontWeight: "600",
                    fontSize: "14px",
                    lineHeight: "16px",
                    color: "#525252",
                    my: 4,
                  }}
                >
                  ------------- or Sign in with Email -------------
                </Typography>
              </Box>
              <Formik
                initialValues={{
                  email: "",
                  password: "",
                }}
                validationSchema={SignupSchema}
                onSubmit={(values) => {
                  alert(JSON.stringify(values, null, 2));
                }}
              >
                {(props) => (
                  <Form
                    onSubmit={props.handleSubmit}
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "10px",
                      justifyContent: "center",
                    }}
                  >
                    <Typography
                      variant="h6"
                      gutterBottom
                      sx={{
                        fontWeight: 600,
                        fontSize: "16px",
                        lineHeight: "19px",
                        color: "#828282",
                      }}
                    >
                      Email
                    </Typography>
                    <TextField
                      // label="Outlined"
                      variant="outlined"
                      id="email"
                      name="email"
                      placeholder="abc@gmail.com"
                      onChange={props.handleChange}
                      value={props.values.email}
                      error={props.touched.email && props.errors.email}
                      helperText={props.touched.email && props.errors.email}
                      onBlur={props.handleBlur}
                    />

                    <Typography
                      variant="h6"
                      gutterBottom
                      sx={{
                        fontWeight: 600,
                        fontSize: "16px",
                        lineHeight: "19px",
                        color: "#828282",
                      }}
                    >
                      Password
                    </Typography>
                    <TextField
                      // label="Outlined"
                      variant="outlined"
                      id="password"
                      type="password"
                      name="password"
                      placeholder="enter your password"
                      onChange={props.handleChange}
                      value={props.values.password}
                      error={props.touched.password && props.errors.password}
                      helperText={
                        props.touched.password && props.errors.password
                      }
                      onBlur={props.handleBlur}
                    />

                    <Box sx={{ display: "flex", alignItems: "center" }}>
                      <Checkbox />
                      <Typography sx={{ flexGrow: 1 }}>remeber me</Typography>
                      <Link>Forgot Password?</Link>
                    </Box>
                    <Button
                      variant="contained"
                      type="submit"
                      sx={{
                        justifyContent: "center",
                        alignItems: "center",
                        padding: "13px 10px 12px",
                        gap: "13px",
                        width: "420px",
                        height: "50px",
                        background: "#7F265B",
                        borderRadius: "6px",
                      }}
                    >
                      LogIn
                    </Button>
                    <Box sx={{ my: 10 }}>
                      <Typography
                        variant="h6"
                        gutterBottom
                        sx={{
                          fontWeight: 400,
                          fontSize: "18px",
                          lineHeight: "25px",
                          color: "#828282",
                          flexGrow: 2,
                        }}
                      >
                        Not Registered yet?
                        <Link
                          onClick={() => Navigate("/signup")}
                          sx={{
                            fontweight: 600,
                            fontSize: "18px",
                            lineheight: "25px",
                            color: "#7F265B",
                          }}
                        >
                          Create an account
                        </Link>
                      </Typography>
                    </Box>
                  </Form>
                )}
              </Formik>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
    // </RecipeReviewCard>
  );
};
export default Login;
