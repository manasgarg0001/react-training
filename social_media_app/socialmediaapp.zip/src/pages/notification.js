import React from "react";

const Notification = () => {
  return <h1>notification page</h1>;
};
export default Notification;
