import React from "react";

const Watch = () => {
  return <h1>Watch page</h1>;
};
export default Watch;
