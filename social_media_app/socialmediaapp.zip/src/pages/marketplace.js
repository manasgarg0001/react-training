import React from "react";

const MarketPlace = () => {
  return <h1>MarketPlace </h1>;
};
export default MarketPlace;
